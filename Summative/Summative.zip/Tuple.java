public class Tuple {
    int val1;
    int val2;
    public Tuple(int val1 , int val2){
        this.val1 = val1;
        this.val2 = val2;
    }
    public String print(){
        return (this.val1 + ", " + this.val2);
    }


}
